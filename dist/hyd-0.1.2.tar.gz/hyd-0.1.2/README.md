### Install

```
pip install hyd
```

### Running

Just put `hyd` inside of your terminal of choice!  
